#ifndef API_CREDENTIALS_H
#define API_CREDENTIALS_H

// API Key
extern const char* thingSpeakApiKey;
extern const char* FirebaseApiKey;

// Base URL
extern const char* thingSpeakBaseUrl;
extern const char* FirebaseBaseUrl;

extern const char* USER_EMAIL;
extern const char* USER_PASSWORD;

#endif  // API_CREDENTIALS_H
