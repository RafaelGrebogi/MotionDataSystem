#include "http_handler.h"
#include "wifi_handler.h"


//Provide the token generation process info.
#include "addons/TokenHelper.h"
//Provide the RTDB payload printing info and other helper functions.
#include "addons/RTDBHelper.h"


// WiFiClient client;


FirebaseData fbdo;
FirebaseAuth auth;
FirebaseConfig config;



//#################################################################
void initiliaseFirebase(){
  config.api_key = FirebaseApiKey;
  config.database_url = FirebaseBaseUrl;
  config.host = FirebaseBaseUrl;

  auth.user.email = USER_EMAIL;
  // auth.user.password = USER_PASSWORD;

  // /* Sign up */
  // if (Firebase.signUp(&config, &auth, "", "")){
  //   Serial.println("Signed up.");
  // }
  // else{
  //   Serial.printf("%s\n", config.signer.signupError.message.c_str());
  // }

  /* Assign the callback function for the long running token generation task */
  config.token_status_callback = tokenStatusCallback; //see addons/TokenHelper.h
  
  Firebase.begin(&config, &auth);
  Firebase.reconnectNetwork(true);

  // $$$$$$$$ DEBUG PROCEDURE $$$$$$$$$$$$
  Serial.print("API Key: ");
  Serial.println(config.api_key.c_str());
  
  Serial.print("Database URL: ");
  Serial.println(FirebaseBaseUrl);
  delay(5000);

  debugInternetConnection();

  if (Firebase.ready()) {
    Serial.println("✅ Firebase successfully initialized.");
} else {
    Serial.println("❌ Firebase initialization failed. Debugging...");

    // Print authentication errors
    if (config.signer.tokens.status == token_status_error) {
        Serial.print("Firebase Auth Error: ");
        Serial.println(config.signer.tokens.error.message.c_str());
    }

    // Check if WiFi is connected
    if (WiFi.status() != WL_CONNECTED) {
        Serial.println("❌ WiFi is NOT connected. Firebase cannot initialize.");
    } else {
        Serial.println("✅ WiFi is connected, but Firebase is not ready.");
    }
}


}

//#################################################################
void sendDataToFirebase(String jsonData) {
  FirebaseJson json;
  json.setJsonData(jsonData);  // Convert String to FirebaseJson

  Serial.println(" sendDataToFirebase()!");
  Serial.print("Firebase Ready: ");
    Serial.println(Firebase.ready() ? "Yes" : "No");

  if (Firebase.ready()) {
      if (Firebase.RTDB.setJSON(&fbdo, "/ESP32/Data", &json)) {
          Serial.println(" Data sent to Firebase!");
      } else {
          Serial.print(" Firebase Error: ");
          Serial.println(fbdo.errorReason());
      }
  }
}
//#################################################################

void debugInternetConnection(){
  if (WiFi.status() == WL_CONNECTED) {
    Serial.println("✅ WiFi is connected. Testing Internet access...");
    // WiFiClient client;
    if (!client.connect("www.google.com", 80)) {
        Serial.println("❌ Internet access FAILED! Check network connection.");
    } else {
        Serial.println("✅ Internet is working.");
        client.stop();
    }
  } else {
    Serial.println("❌ WiFi is NOT connected.");
}



}


// int sendDataToThingSpeak(float value) {
//     if (WiFi.status() == WL_CONNECTED) {
//         HTTPClient http;
//         String url = String(thingSpeakBaseUrl) + "?api_key=" + String(thingSpeakApiKey) + "&field1=" + String(value);
//         http.begin(client, url);
//         int httpResponseCode = http.GET();

//         if (httpResponseCode>0) {
//             Serial.print("ThingSpeak Response: ");
//             Serial.println(httpResponseCode);
//           }
//           else {
//             Serial.print("Error code: ");
//             Serial.println(httpResponseCode);
//           }
//           String s = http.getString();
//           Serial.print(s + "\n");
        
//         http.end();
//         return httpResponseCode;
//     } else {
//         Serial.println("WiFi Disconnected");
//         return -1;
//     }
// }