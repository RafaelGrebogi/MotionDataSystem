#include "api_credentials.h"

// Define ThingSpeak API credentials
const char* thingSpeakApiKey = "LC674RK1DZJ49A4F";  // Replace with your real API key
const char* thingSpeakBaseUrl = "http://api.thingspeak.com/update";

// // Define Firebase API credentials
const char* FirebaseApiKey = "AIzaSyAwVRSBtgjI3p6P04HGwUgyuU9kTCu-7sk";  // Replace with your real API key
const char* FirebaseBaseUrl = "https://esp32-datalogger-c9c32-default-rtdb.asia-southeast1.firebasedatabase.app/";


// Authorised Email and Corresponding Password
const char* USER_EMAIL = "rafagrebogi@gmail.com";
const char* USER_PASSWORD = "test";